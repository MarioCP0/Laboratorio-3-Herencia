import java.io.*;
import java.util.Random;

/**
 * Clase que representa un espacio genérico.
 */
public class espacio {
    private int ID; // Identificador único del espacio.
    private double MetrosCuadrados; // Metros cuadrados del espacio.
    private int CantidadDisponible; // Cantidad disponible de este espacio.
    private int CantidadVendidos; // Cantidad de este espacio que han sido vendidos.
    private String Estado; // Estado del espacio (Ejemplo: "disponible", "reservado", "vendido").

    /**
     * Constructor de la clase "espacio".
     *
     * @param MetrosCuadrados    Metros cuadrados del espacio.
     * @param CantidadDisponible Cantidad disponible de este espacio.
     * @param CantidadVendidos   Cantidad de este espacio que han sido vendidos.
     * @param Estado             Estado del espacio.
     */
    public espacio(double MetrosCuadrados, int CantidadDisponible, int CantidadVendidos, String Estado) {
        this.ID = generarIDAleatorio(); // Genera un ID aleatorio
        this.MetrosCuadrados = MetrosCuadrados;
        this.CantidadDisponible = CantidadDisponible;
        this.CantidadVendidos = CantidadVendidos;
        this.Estado = Estado;
    }

    /**
     * Obtiene el identificador único del espacio.
     *
     * @return El ID del espacio.
     */
    public int getID() {
        return ID;
    }

    /**
     * Obtiene los metros cuadrados del espacio.
     *
     * @return Los metros cuadrados del espacio.
     */
    public double getMetrosCuadrados() {
        return MetrosCuadrados;
    }

    /**
     * Obtiene la cantidad disponible de este espacio.
     *
     * @return La cantidad disponible del espacio.
     */
    public int getCantidadDisponible() {
        return CantidadDisponible;
    }

    /**
     * Obtiene la cantidad de este espacio que ha sido vendida.
     *
     * @return La cantidad vendida del espacio.
     */
    public int getCantidadVendidos() {
        return CantidadVendidos;
    }

    /**
     * Obtiene el estado del espacio.
     *
     * @return El estado del espacio.
     */
    public String getEstado() {
        return Estado;
    }

    /**
     * Establece la cantidad disponible de este espacio.
     *
     * @param CantidadDisponible La cantidad disponible del espacio.
     */
    public void setCantidadDisponible(int CantidadDisponible) {
        this.CantidadDisponible = CantidadDisponible;
    }

    /**
     * Establece la cantidad de este espacio que ha sido vendida.
     *
     * @param CantidadVendidos La cantidad vendida del espacio.
     */
    public void setCantidadVendidos(int CantidadVendidos) {
        this.CantidadVendidos = CantidadVendidos;
    }

    /**
     * Establece el estado del espacio.
     *
     * @param Estado El estado del espacio.
     */
    public void setEstado(String Estado) {
        this.Estado = Estado;
    }

    /**
     * Genera un ID aleatorio para el espacio.
     *
     * @return Un ID aleatorio.
     */
    private int generarIDAleatorio() {
        Random rand = new Random();
        return rand.nextInt(100000); // Puedes ajustar el rango de IDs según tus necesidades.
    }

    /**
     * Convierte los datos del espacio a una cadena CSV.
     *
     * @return Una cadena en formato CSV que representa los datos del espacio.
     */
    public String toCSV() {
        return ID + "," + MetrosCuadrados + "," + CantidadDisponible + "," + CantidadVendidos + "," + Estado;
    }

    /**
     * Crea un objeto de espacio a partir de una cadena CSV.
     *
     * @param csvLine La cadena CSV que contiene los datos del espacio.
     * @return Un objeto de espacio con los datos proporcionados.
     */
    public static espacio fromCSV(String csvLine) {
        String[] data = csvLine.split(",");
        int id = Integer.parseInt(data[0]);
        double metrosCuadrados = Double.parseDouble(data[1]);
        int cantidadDisponible = Integer.parseInt(data[2]);
        int cantidadVendidos = Integer.parseInt(data[3]);
        String estado = data[4];
        espacio espacio = new espacio(metrosCuadrados, cantidadDisponible, cantidadVendidos, estado);
        espacio.ID = id;
        return espacio;
    }

    /**
     * Método para guardar el espacio en un archivo CSV.
     *
     * @param archivoCSV Ruta del archivo CSV donde se guardarán los datos del espacio.
     */
    public void guardarEnCSV(String archivoCSV) {
        try (FileWriter writer = new FileWriter(archivoCSV, true);
             BufferedWriter bufferWriter = new BufferedWriter(writer)) {
            bufferWriter.write(this.toCSV());
            bufferWriter.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
