/**
 * Clase que representa un tipo específico de espacio llamado "amenidad".
 * Extiende la clase base "espacio" e incluye atributos y métodos específicos para las amenidades.
 */
public class amenidad extends espacio {
    private String Tipo; // Tipo de amenidad (Ejemplo: Piscina, Gimnasio, Salón de eventos, etc.)
    private int CapacidadPersonas; // Capacidad máxima de personas que pueden usar la amenidad

    /**
     * Constructor de la clase "amenidad".
     *
     * @param ID                 Identificador único del espacio.
     * @param MetrosCuadrados    Metros cuadrados del espacio.
     * @param CantidadDisponible Cantidad disponible de este espacio.
     * @param CantidadVendidos   Cantidad de este espacio que han sido vendidos.
     * @param Estado             Estado del espacio (Ejemplo: "disponible", "reservado", "vendido").
     * @param Tipo               Tipo de amenidad.
     * @param CapacidadPersonas  Capacidad máxima de personas para la amenidad.
     */
    public amenidad(int ID, double MetrosCuadrados, int CantidadDisponible, int CantidadVendidos, String Estado,
                    String Tipo, int CapacidadPersonas) {
        super(MetrosCuadrados, CantidadDisponible, CantidadVendidos, Estado);
        this.Tipo = Tipo;
        this.CapacidadPersonas = CapacidadPersonas;
    }

    /**
     * Obtiene el tipo de la amenidad.
     *
     * @return El tipo de la amenidad.
     */
    public String getTipo() {
        return Tipo;
    }

    /**
     * Establece el tipo de la amenidad.
     *
     * @param Tipo El tipo de la amenidad.
     */
    public void setTipo(String Tipo) {
        this.Tipo = Tipo;
    }

    /**
     * Obtiene la capacidad máxima de personas que pueden usar la amenidad.
     *
     * @return La capacidad máxima de personas.
     */
    public int getCapacidadPersonas() {
        return CapacidadPersonas;
    }

    /**
     * Establece la capacidad máxima de personas que pueden usar la amenidad.
     *
     * @param CapacidadPersonas La capacidad máxima de personas.
     */
    public void setCapacidadPersonas(int CapacidadPersonas) {
        this.CapacidadPersonas = CapacidadPersonas;
    }
}
