/**
 * Clase que representa un tipo específico de espacio llamado "apartamento".
 * Extiende la clase base "espacio" e incluye atributos y métodos específicos para los apartamentos.
 */
public class apartamento extends espacio {
    private boolean LineaBlanca; // Indica si el apartamento incluye línea blanca (electrodomésticos).
    private int Habitaciones; // Número de habitaciones en el apartamento.

    /**
     * Constructor de la clase "apartamento".
     *
     * @param MetrosCuadrados    Metros cuadrados del apartamento.
     * @param CantidadDisponible Cantidad disponible de este apartamento.
     * @param CantidadVendidos   Cantidad de este apartamento que ha sido vendida.
     * @param Estado             Estado del apartamento.
     * @param LineaBlanca        Indica si el apartamento incluye línea blanca.
     * @param Habitaciones       Número de habitaciones en el apartamento.
     */
    public apartamento(double MetrosCuadrados, int CantidadDisponible, int CantidadVendidos, String Estado,
                      boolean LineaBlanca, int Habitaciones) {
        super(MetrosCuadrados, CantidadDisponible, CantidadVendidos, Estado); // ID se generará aleatoriamente
        this.LineaBlanca = LineaBlanca;
        this.Habitaciones = Habitaciones;
    }

    /**
     * Indica si el apartamento incluye línea blanca (electrodomésticos).
     *
     * @return true si el apartamento incluye línea blanca, false de lo contrario.
     */
    public boolean isLineaBlanca() {
        return LineaBlanca;
    }

    /**
     * Establece si el apartamento incluye línea blanca (electrodomésticos).
     *
     * @param LineaBlanca true si el apartamento incluye línea blanca, false de lo contrario.
     */
    public void setLineaBlanca(boolean LineaBlanca) {
        this.LineaBlanca = LineaBlanca;
    }

    /**
     * Obtiene el número de habitaciones en el apartamento.
     *
     * @return El número de habitaciones.
     */
    public int getHabitaciones() {
        return Habitaciones;
    }

    /**
     * Establece el número de habitaciones en el apartamento.
     *
     * @param Habitaciones El número de habitaciones.
     */
    public void setHabitaciones(int Habitaciones) {
        this.Habitaciones = Habitaciones;
    }
}
