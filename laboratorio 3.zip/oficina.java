/**
 * Clase que representa un tipo específico de espacio llamado "oficina".
 * Extiende la clase base "espacio" e incluye atributos y métodos específicos para las oficinas.
 */
public class oficina extends espacio {
    private int TotalParqueos; // Total de parqueos disponibles en la oficina.
    private boolean Mantenimiento; // Indica si la oficina está en mantenimiento o no.

    /**
     * Constructor de la clase "oficina".
     *
     * @param ID                 Identificador único de la oficina.
     * @param MetrosCuadrados    Metros cuadrados de la oficina.
     * @param CantidadDisponible Cantidad disponible de esta oficina.
     * @param CantidadVendidos   Cantidad de esta oficina que han sido vendidos.
     * @param Estado             Estado de la oficina.
     * @param TotalParqueos      Total de parqueos disponibles en la oficina.
     * @param Mantenimiento      Indica si la oficina está en mantenimiento.
     */
    public oficina(int ID, double MetrosCuadrados, int CantidadDisponible, int CantidadVendidos, String Estado,
                   int TotalParqueos, boolean Mantenimiento) {
        super(MetrosCuadrados, CantidadDisponible, CantidadVendidos, Estado);
        this.TotalParqueos = TotalParqueos;
        this.Mantenimiento = Mantenimiento;
    }

    /**
     * Obtiene el total de parqueos disponibles en la oficina.
     *
     * @return El total de parqueos disponibles.
     */
    public int getTotalParqueos() {
        return TotalParqueos;
    }

    /**
     * Establece el total de parqueos disponibles en la oficina.
     *
     * @param TotalParqueos El total de parqueos disponibles.
     */
    public void setTotalParqueos(int TotalParqueos) {
        this.TotalParqueos = TotalParqueos;
    }

    /**
     * Indica si la oficina está en mantenimiento.
     *
     * @return true si la oficina está en mantenimiento, false de lo contrario.
     */
    public boolean isMantenimiento() {
        return Mantenimiento;
    }

    /**
     * Establece si la oficina está en mantenimiento o no.
     *
     * @param Mantenimiento true si la oficina está en mantenimiento, false de lo contrario.
     */
    public void setMantenimiento(boolean Mantenimiento) {
        this.Mantenimiento = Mantenimiento;
    }
}
