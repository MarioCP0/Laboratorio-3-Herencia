//UNIVERSIDAD DEL VALLE DE GUATEMALA 
//ISABELLA RAMÍREZ Y MARIO CABREREA
//PROGRAMACIÓN ORIENTADA A OBJETOS
import java.util.*;
import java.io.*;

/**
 * Clase para gestionar espacios en Space UVG.
 */
public class SpaceUVGManager {
    private ArrayList<espacio> espacios;

    /**
     * Constructor de la clase SpaceUVGManager. Inicializa la lista de espacios.
     */
    public SpaceUVGManager() {
        espacios = new ArrayList<>();
    }

    /**
     * Método para cargar espacios desde un archivo CSV.
     *
     * @param archivoCSV Ruta del archivo CSV que contiene los espacios.
     */
    public void cargarEspaciosDesdeCSV(String archivoCSV) {
        try (BufferedReader br = new BufferedReader(new FileReader(archivoCSV))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                espacio espacioObj = espacio.fromCSV(linea); // Cambia el nombre de la variable
                espacios.add(espacioObj);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * Método para buscar un espacio por su ID.
     *
     * @param id El ID del espacio a buscar.
     * @return El espacio encontrado o null si no se encuentra.
     */
    public espacio buscarEspacioPorID(int id) {
        for (espacio espacio : espacios) {
            if (espacio.getID() == id) {
                return espacio;
            }
        }
        return null; // Espacio no encontrado
    }

    /**
     * Método para listar espacios de una categoría específica.
     *
     * @param categoria La categoría de espacios a listar.
     * @return Una lista de espacios de la categoría especificada.
     */
    public ArrayList<espacio> listarEspaciosPorCategoria(String categoria) {
        ArrayList<espacio> espaciosCategoria = new ArrayList<>();
        for (espacio espacio : espacios) {
            if (espacio.getClass().getSimpleName().equalsIgnoreCase(categoria)) {
                espaciosCategoria.add(espacio);
            }
        }
        return espaciosCategoria;
    }

    /**
     * Método para mostrar el estado de los espacios por categoría.
     *
     * @param categoria La categoría de espacios para mostrar el estado.
     */
    public void mostrarEstadoEspaciosPorCategoria(String categoria) {
        int disponibles = 0;
        int reservados = 0;
        int vendidos = 0;

        for (espacio espacio : espacios) {
            if (espacio.getClass().getSimpleName().equalsIgnoreCase(categoria)) {
                if (espacio.getEstado().equalsIgnoreCase("disponible")) {
                    disponibles++;
                } else if (espacio.getEstado().equalsIgnoreCase("reservado")) {
                    reservados++;
                } else if (espacio.getEstado().equalsIgnoreCase("vendido")) {
                    vendidos++;
                }
            }
        }

        System.out.println("Espacios " + categoria + " disponibles: " + disponibles);
        System.out.println("Espacios " + categoria + " reservados: " + reservados);
        System.out.println("Espacios " + categoria + " vendidos: " + vendidos);
    }

    /**
     * Método para generar un informe que muestra información de los espacios.
     */
    public void generarInforme() {
        // Listado de categorías con el total de espacios registrados
        HashMap<String, Integer> categoriasTotales = new HashMap<>();
        for (espacio espacio : espacios) {
            String categoria = espacio.getClass().getSimpleName();
            categoriasTotales.put(categoria, categoriasTotales.getOrDefault(categoria, 0) + 1);
        }

        // Listado de espacios por categoría
        System.out.println("Listado de espacios por categoría:");
        for (String categoria : categoriasTotales.keySet()) {
            System.out.println(categoria + " - " + categoriasTotales.get(categoria));
        }

        // Total de espacios por estado por categoría
        for (String categoria : categoriasTotales.keySet()) {
            mostrarEstadoEspaciosPorCategoria(categoria);
        }
    }

    /**
     * Método principal que inicia la aplicación.
     *
     * @param args Argumentos de línea de comandos (no utilizados en este caso).
     */
    public static void main(String[] args) {
        SpaceUVGManager manager = new SpaceUVGManager();
        manager.cargarEspaciosDesdeCSV("espacios.csv");

        Scanner scanner = new Scanner(System.in);
        boolean salir = false;

        while (!salir) {
            System.out.println("----- Menú de Space UVG -----");
            System.out.println("1. Buscar espacio por ID");
            System.out.println("2. Listar espacios por categoría");
            System.out.println("3. Mostrar estado de espacios por categoría");
            System.out.println("4. Generar informe");
            System.out.println("5. Salir");
            System.out.print("Seleccione una opción: ");

            int opcion = scanner.nextInt();

            switch (opcion) {
                case 1:
                    // ...
                    break;

                case 2:
                    // ...
                    break;

                case 3:
                    // ...
                    break;

                case 4:
                    // ...
                    break;

                case 5:
                    salir = true;
                    break;

                default:
                    System.out.println("Opción no válida. Intente de nuevo.");
            }
        }

        scanner.close();
    }
}
